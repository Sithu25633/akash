
import { GoogleGenAI } from "@google/genai";

export async function generateRomanticMessage(prompt: string) {
  if (!process.env.API_KEY) {
    throw new Error("API Key not found. Please ensure it is configured.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are a romantic soul and poetic writer. Your task is to generate beautiful, deeply romantic love messages, quotes, or letters. Keep them intimate, meaningful, and emotionally resonant. Use metaphors and soft language.",
        temperature: 0.9,
      }
    });

    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Even the stars are silent right now, but my heart still beats for you.";
  }
}
