
import React from 'react';
import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

export const SplashScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  return (
    <motion.div 
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-slate-950 text-white cursor-pointer"
      initial={{ opacity: 1 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onComplete}
    >
      <motion.div
        animate={{ 
          scale: [1, 1.2, 1],
          filter: ["drop-shadow(0 0 10px #f43f5e)", "drop-shadow(0 0 30px #f43f5e)", "drop-shadow(0 0 10px #f43f5e)"]
        }}
        transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
        className="mb-8"
      >
        <Heart size={120} fill="#f43f5e" color="#f43f5e" />
      </motion.div>
      
      <motion.h1 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="text-4xl font-romantic text-rose-500 mb-2"
      >
        Mage Manika
      </motion.h1>
      
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="text-slate-400 text-sm tracking-widest uppercase"
      >
        Tap to Enter Your World
      </motion.p>
      
      <motion.div 
        className="absolute bottom-10 left-0 right-0 text-center text-xs text-rose-900 font-medium"
        animate={{ opacity: [0, 1, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        FOR YOUR EYES ONLY
      </motion.div>
    </motion.div>
  );
};
