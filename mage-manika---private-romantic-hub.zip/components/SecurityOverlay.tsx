
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Lock, Unlock } from 'lucide-react';
import { PIN_CODE } from '../constants';

export const SecurityOverlay: React.FC<{ onUnlock: (s: boolean) => void }> = ({ onUnlock }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState(false);

  const handleEntry = (val: string) => {
    const newPin = pin + val;
    if (newPin.length <= 4) {
      setPin(newPin);
      if (newPin.length === 4) {
        if (newPin === PIN_CODE) {
          onUnlock(true);
        } else {
          setError(true);
          setTimeout(() => {
            setPin('');
            setError(false);
          }, 600);
        }
      }
    }
  };

  const shakeAnimation = {
    x: [0, -10, 10, -10, 10, 0],
    transition: { duration: 0.4 }
  };

  return (
    <div className="fixed inset-0 z-[90] flex flex-col items-center justify-center bg-slate-900 px-6">
      <motion.div 
        animate={error ? shakeAnimation : {}}
        className="w-full max-w-xs flex flex-col items-center"
      >
        <div className={`p-6 rounded-full bg-slate-800 mb-8 border-2 ${error ? 'border-rose-500' : 'border-slate-700'}`}>
          {pin.length === 4 && !error ? <Unlock className="text-emerald-500" size={40} /> : <Lock className="text-rose-500" size={40} />}
        </div>
        
        <h2 className="text-2xl font-semibold mb-2">Security Check</h2>
        <p className="text-slate-400 mb-12 text-center text-sm">Please enter the private access code to proceed.</p>
        
        <div className="flex gap-4 mb-12">
          {[1, 2, 3, 4].map((i) => (
            <div 
              key={i} 
              className={`w-4 h-4 rounded-full border-2 border-rose-500 transition-all duration-200 ${pin.length >= i ? 'bg-rose-500' : 'bg-transparent'}`} 
            />
          ))}
        </div>

        <div className="grid grid-cols-3 gap-6 w-full">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
            <button
              key={num}
              onClick={() => handleEntry(num.toString())}
              className="h-16 w-16 rounded-full bg-slate-800 text-xl font-medium active:bg-rose-500 active:scale-90 transition-all flex items-center justify-center"
            >
              {num}
            </button>
          ))}
          <div />
          <button
            onClick={() => handleEntry('0')}
            className="h-16 w-16 rounded-full bg-slate-800 text-xl font-medium active:bg-rose-500 active:scale-90 transition-all flex items-center justify-center"
          >
            0
          </button>
          <button
            onClick={() => setPin(pin.slice(0, -1))}
            className="h-16 w-16 rounded-full bg-slate-800/50 text-xs font-bold active:bg-slate-700 active:scale-90 transition-all flex items-center justify-center"
          >
            DEL
          </button>
        </div>
      </motion.div>
    </div>
  );
};
