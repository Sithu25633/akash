
import React from 'react';
import { NAVIGATION_ITEMS } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (id: string) => void;
  backgroundUrl: string | null;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, setActiveTab, backgroundUrl }) => {
  return (
    <div className="relative h-screen w-screen flex flex-col overflow-hidden bg-black">
      {/* Dynamic Background */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-40 blur-[2px] scale-105"
        style={{ backgroundImage: `url(${backgroundUrl})` }}
      />
      <div className="absolute inset-0 z-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent" />

      {/* Content Area */}
      <main className="relative z-10 flex-1 w-full overflow-hidden">
        {children}
      </main>

      {/* Navigation */}
      <nav className="relative z-20 bg-slate-950/80 backdrop-blur-xl border-t border-rose-500/20 px-6 py-4 pb-8 flex justify-between items-center">
        {NAVIGATION_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center transition-all ${activeTab === item.id ? 'text-rose-500 scale-110' : 'text-slate-500'}`}
          >
            <div className={`p-2 rounded-2xl transition-all ${activeTab === item.id ? 'bg-rose-500/10' : ''}`}>
              {item.icon}
            </div>
            <span className="text-[10px] mt-1 font-bold uppercase tracking-tighter">
              {item.label}
            </span>
            {activeTab === item.id && (
              <div className="w-1 h-1 bg-rose-500 rounded-full mt-1" />
            )}
          </button>
        ))}
      </nav>
    </div>
  );
};
