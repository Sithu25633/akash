
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Send, Copy, Heart, Loader2 } from 'lucide-react';
import { generateRomanticMessage } from '../services/gemini';

export const GeminiAI: React.FC<{ messages: { text: string; date: string }[]; onUpdate: (m: { text: string; date: string }[]) => void }> = ({ messages, onUpdate }) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    if (!input) return;
    setLoading(true);
    const result = await generateRomanticMessage(input);
    const newMessage = { text: result || '', date: new Date().toLocaleString() };
    onUpdate([newMessage, ...messages]);
    setLoading(false);
    setInput('');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('Copied to clipboard!');
  };

  return (
    <div className="p-6 h-full flex flex-col">
      <header className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <Sparkles className="text-rose-500" />
          <h1 className="text-2xl font-bold">AI Muse</h1>
        </div>
        <p className="text-slate-400 text-sm">Let AI help you find the right words for your love.</p>
      </header>

      <div className="flex-1 overflow-y-auto space-y-4 mb-6 pr-1">
        <AnimatePresence>
          {messages.map((msg, i) => (
            <motion.div 
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-slate-900/60 border border-white/5 rounded-3xl p-6 shadow-lg"
            >
              <p className="text-lg font-serif italic text-rose-100 leading-relaxed mb-4">{msg.text}</p>
              <div className="flex items-center justify-between border-t border-white/5 pt-4">
                <span className="text-[10px] text-slate-500 uppercase tracking-widest">{msg.date}</span>
                <div className="flex gap-3">
                  <button onClick={() => copyToClipboard(msg.text)} className="p-2 hover:bg-white/5 rounded-full text-slate-400 transition-colors"><Copy size={16}/></button>
                  <button className="p-2 hover:bg-white/5 rounded-full text-rose-500 transition-colors"><Heart size={16}/></button>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        
        {messages.length === 0 && !loading && (
          <div className="h-full flex flex-col items-center justify-center text-center opacity-30 mt-20">
            <Heart size={64} className="mb-4" />
            <p>Ask for a love letter, a poem, <br/> or a message for an occasion.</p>
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center justify-center py-10 opacity-50">
            <Loader2 className="animate-spin text-rose-500 mb-2" />
            <span className="text-xs uppercase tracking-[0.2em]">Whispering to the stars...</span>
          </div>
        )}
      </div>

      <div className="relative">
        <textarea 
          placeholder="Ask AI: 'Write a short poem about her eyes'..."
          className="w-full bg-slate-900 border border-slate-700 rounded-3xl px-6 py-4 pr-16 focus:outline-none focus:border-rose-500 text-white min-h-[80px] resize-none"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={loading}
        />
        <button 
          onClick={handleGenerate}
          disabled={loading || !input}
          className="absolute bottom-4 right-4 p-4 bg-rose-600 text-white rounded-2xl shadow-lg active:scale-90 disabled:opacity-50 disabled:scale-100 transition-all"
        >
          <Send size={20} />
        </button>
      </div>
    </div>
  );
};
