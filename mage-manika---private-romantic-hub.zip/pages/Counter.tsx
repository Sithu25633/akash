
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Settings } from 'lucide-react';

export const Counter: React.FC<{ startDate: string; title: string; onUpdate: (d: string, t: string) => void }> = ({ startDate, title, onUpdate }) => {
  const [now, setNow] = useState(new Date());
  const [showSettings, setShowSettings] = useState(false);
  const [tempTitle, setTempTitle] = useState(title);
  const [tempDate, setTempDate] = useState(startDate.split('T')[0]);

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const start = new Date(startDate);
  const diff = now.getTime() - start.getTime();

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / 1000 / 60) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  const handleUpdate = () => {
    onUpdate(new Date(tempDate).toISOString(), tempTitle);
    setShowSettings(false);
  };

  return (
    <div className="p-6 h-full flex flex-col items-center justify-center text-center">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-12"
      >
        <h2 className="text-4xl font-romantic text-rose-500 neon-glow mb-4">{title}</h2>
        <div className="bg-rose-500/10 border border-rose-500/20 px-4 py-1 rounded-full text-[10px] uppercase tracking-[0.3em] inline-block font-bold">
          Since {start.toLocaleDateString()}
        </div>
      </motion.div>

      <div className="flex flex-col gap-8 w-full">
        <div className="flex justify-center gap-4">
          <div className="flex flex-col items-center">
            <div className="text-6xl font-black text-white neon-glow tabular-nums">{days}</div>
            <div className="text-[10px] uppercase tracking-widest text-rose-500 font-bold mt-2">Days</div>
          </div>
          <div className="text-6xl font-black opacity-30">:</div>
          <div className="flex flex-col items-center">
            <div className="text-6xl font-black text-white neon-glow tabular-nums">{hours.toString().padStart(2, '0')}</div>
            <div className="text-[10px] uppercase tracking-widest text-rose-500 font-bold mt-2">Hours</div>
          </div>
        </div>
        <div className="flex justify-center gap-10">
          <div className="flex flex-col items-center">
            <div className="text-4xl font-bold text-white/80 tabular-nums">{minutes.toString().padStart(2, '0')}</div>
            <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mt-1">Mins</div>
          </div>
          <div className="flex flex-col items-center">
            <div className="text-4xl font-bold text-white/80 tabular-nums">{seconds.toString().padStart(2, '0')}</div>
            <div className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mt-1">Secs</div>
          </div>
        </div>
      </div>

      <button 
        onClick={() => setShowSettings(true)}
        className="mt-16 p-4 bg-slate-900/50 rounded-full text-slate-500 active:text-rose-500 transition-colors"
      >
        <Settings size={24} />
      </button>

      {showSettings && (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6">
          <div className="w-full max-w-sm bg-slate-900 border border-rose-500/20 rounded-3xl p-8">
            <h3 className="text-xl font-bold mb-6">Counter Settings</h3>
            <div className="space-y-6">
              <div>
                <label className="block text-xs uppercase tracking-widest text-slate-400 mb-2 font-bold">Event Title</label>
                <input 
                  type="text" 
                  className="w-full bg-slate-800 rounded-2xl px-4 py-3 focus:outline-none border border-transparent focus:border-rose-500"
                  value={tempTitle}
                  onChange={(e) => setTempTitle(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-xs uppercase tracking-widest text-slate-400 mb-2 font-bold">Start Date</label>
                <input 
                  type="date" 
                  className="w-full bg-slate-800 rounded-2xl px-4 py-3 focus:outline-none border border-transparent focus:border-rose-500 text-white"
                  value={tempDate}
                  onChange={(e) => setTempDate(e.target.value)}
                />
              </div>
              <div className="flex gap-4 pt-4">
                <button onClick={() => setShowSettings(false)} className="flex-1 py-3 bg-slate-800 rounded-2xl font-bold">Cancel</button>
                <button onClick={handleUpdate} className="flex-1 py-3 bg-rose-600 rounded-2xl font-bold">Save</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
