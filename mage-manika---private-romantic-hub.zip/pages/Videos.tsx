
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Folder, Plus, ChevronLeft, Upload, Trash2, Play, X } from 'lucide-react';
import { Folder as FolderType, MediaFile } from '../types';

export const Videos: React.FC<{ folders: FolderType[]; onUpdate: (f: FolderType[]) => void }> = ({ folders, onUpdate }) => {
  const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
  const [showAddFolder, setShowAddFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [selectedVideo, setSelectedVideo] = useState<MediaFile | null>(null);

  const activeFolder = folders.find(f => f.id === activeFolderId);

  const handleAddFolder = () => {
    if (newFolderName) {
      const newFolder: FolderType = {
        id: Date.now().toString(),
        name: newFolderName,
        files: []
      };
      onUpdate([...folders, newFolder]);
      setNewFolderName('');
      setShowAddFolder(false);
    }
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && activeFolderId) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newFile: MediaFile = {
          id: Date.now().toString(),
          url: reader.result as string,
          name: file.name,
          type: 'video',
          timestamp: Date.now()
        };
        const updatedFolders = folders.map(f => 
          f.id === activeFolderId ? { ...f, files: [newFile, ...f.files] } : f
        );
        onUpdate(updatedFolders);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeleteFile = (id: string) => {
    if (window.confirm('Delete this video memory?')) {
      const updatedFolders = folders.map(f => 
        f.id === activeFolderId ? { ...f, files: f.files.filter(file => file.id !== id) } : f
      );
      onUpdate(updatedFolders);
    }
  };

  if (activeFolder) {
    return (
      <div className="p-6 h-full">
        <header className="flex items-center justify-between mb-8">
          <button onClick={() => setActiveFolderId(null)} className="flex items-center gap-2 text-rose-500 font-bold">
            <ChevronLeft size={20} />
            Back
          </button>
          <h2 className="text-xl font-bold truncate max-w-[150px]">{activeFolder.name}</h2>
          <div className="relative overflow-hidden w-10 h-10 bg-rose-600 rounded-full flex items-center justify-center">
            <Upload size={20} />
            <input 
              type="file" 
              accept="video/*" 
              className="absolute inset-0 opacity-0 cursor-pointer"
              onChange={handleUpload}
            />
          </div>
        </header>

        <div className="grid grid-cols-1 gap-4">
          {activeFolder.files.map((file) => (
            <motion.div 
              key={file.id} 
              className="relative aspect-video rounded-3xl overflow-hidden bg-slate-900 border border-white/5 shadow-lg"
            >
              <video src={file.url} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/50 flex flex-col justify-end p-6">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold truncate pr-4 opacity-70">{file.name}</span>
                  <div className="flex gap-4">
                    <button onClick={() => setSelectedVideo(file)} className="p-3 bg-white/20 backdrop-blur-md rounded-full"><Play size={20} /></button>
                    <button onClick={() => handleDeleteFile(file.id)} className="p-3 bg-rose-500/20 backdrop-blur-md rounded-full text-rose-500"><Trash2 size={20} /></button>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
          {activeFolder.files.length === 0 && (
            <div className="py-20 text-center text-slate-500">
              <p>No videos here yet.<br/>Share a beautiful moment.</p>
            </div>
          )}
        </div>

        <AnimatePresence>
          {selectedVideo && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-black flex items-center justify-center p-0"
            >
              <button 
                onClick={() => setSelectedVideo(null)}
                className="absolute top-10 right-10 z-[110] p-3 bg-white/10 rounded-full backdrop-blur-xl"
              >
                <X size={24} />
              </button>
              <video 
                src={selectedVideo.url} 
                controls 
                autoPlay
                className="w-full h-full max-h-screen object-contain"
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="p-6 h-full">
      <header className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Video Archives</h1>
        <button 
          onClick={() => setShowAddFolder(true)}
          className="p-2 bg-rose-600 rounded-full"
        >
          <Plus size={20} />
        </button>
      </header>

      <div className="grid grid-cols-2 gap-4">
        {folders.map((folder) => (
          <motion.button
            key={folder.id}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveFolderId(folder.id)}
            className="flex flex-col items-center bg-slate-900/60 p-6 rounded-3xl border border-white/5"
          >
            <Folder size={48} className="text-emerald-500 mb-3" fill="rgba(16, 185, 129, 0.2)" />
            <span className="font-bold truncate w-full text-center">{folder.name}</span>
            <span className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">{folder.files.length} items</span>
          </motion.button>
        ))}
      </div>

      <AnimatePresence>
        {showAddFolder && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-6">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-full max-w-sm bg-slate-900 border border-emerald-500/20 rounded-3xl p-8"
            >
              <h3 className="text-xl font-bold mb-6">New Collection Name</h3>
              <input 
                type="text" 
                autoFocus
                className="w-full bg-slate-800 border border-slate-700 rounded-2xl px-4 py-3 mb-6 focus:outline-none focus:border-emerald-500"
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
              />
              <div className="flex gap-4">
                <button onClick={() => setShowAddFolder(false)} className="flex-1 py-3 bg-slate-800 rounded-2xl font-bold">Cancel</button>
                <button onClick={handleAddFolder} className="flex-1 py-3 bg-emerald-600 rounded-2xl font-bold">Create</button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
