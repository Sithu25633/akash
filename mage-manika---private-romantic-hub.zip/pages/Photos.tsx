
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Folder, Plus, ChevronLeft, Upload, Trash2, Maximize2, X } from 'lucide-react';
import { Folder as FolderType, MediaFile } from '../types';

export const Photos: React.FC<{ folders: FolderType[]; onUpdate: (f: FolderType[]) => void }> = ({ folders, onUpdate }) => {
  const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
  const [showAddFolder, setShowAddFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [selectedImage, setSelectedImage] = useState<MediaFile | null>(null);

  const activeFolder = folders.find(f => f.id === activeFolderId);

  const handleAddFolder = () => {
    if (newFolderName) {
      const newFolder: FolderType = {
        id: Date.now().toString(),
        name: newFolderName,
        files: []
      };
      onUpdate([...folders, newFolder]);
      setNewFolderName('');
      setShowAddFolder(false);
    }
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && activeFolderId) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const newFile: MediaFile = {
          id: Date.now().toString(),
          url: reader.result as string,
          name: file.name,
          type: 'image',
          timestamp: Date.now()
        };
        const updatedFolders = folders.map(f => 
          f.id === activeFolderId ? { ...f, files: [newFile, ...f.files] } : f
        );
        onUpdate(updatedFolders);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDeleteFile = (id: string) => {
    if (window.confirm('Are you sure you want to delete this memory?')) {
      const updatedFolders = folders.map(f => 
        f.id === activeFolderId ? { ...f, files: f.files.filter(file => file.id !== id) } : f
      );
      onUpdate(updatedFolders);
    }
  };

  if (activeFolder) {
    return (
      <div className="p-6 min-h-full">
        <header className="flex items-center justify-between mb-8">
          <button onClick={() => setActiveFolderId(null)} className="flex items-center gap-2 text-rose-500 font-bold">
            <ChevronLeft size={20} />
            Back
          </button>
          <h2 className="text-xl font-bold truncate max-w-[150px]">{activeFolder.name}</h2>
          <div className="relative overflow-hidden w-10 h-10 bg-rose-600 rounded-full flex items-center justify-center">
            <Upload size={20} />
            <input 
              type="file" 
              accept="image/*" 
              className="absolute inset-0 opacity-0 cursor-pointer"
              onChange={handleUpload}
            />
          </div>
        </header>

        <div className="grid grid-cols-2 gap-4">
          {activeFolder.files.map((file) => (
            <motion.div 
              key={file.id} 
              layoutId={file.id}
              className="relative aspect-square rounded-2xl overflow-hidden bg-slate-800 border border-white/5"
            >
              <img src={file.url} className="w-full h-full object-cover" alt={file.name} />
              <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                <button onClick={() => setSelectedImage(file)} className="p-2 bg-white/20 backdrop-blur-md rounded-full"><Maximize2 size={20} /></button>
                <button onClick={() => handleDeleteFile(file.id)} className="p-2 bg-rose-500/20 backdrop-blur-md rounded-full text-rose-500"><Trash2 size={20} /></button>
              </div>
            </motion.div>
          ))}
          {activeFolder.files.length === 0 && (
            <div className="col-span-2 py-20 text-center text-slate-500">
              <p>No photos here yet.<br/>Upload your first memory!</p>
            </div>
          )}
        </div>

        {/* Slideshow Modal */}
        <AnimatePresence>
          {selectedImage && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-[100] bg-black flex items-center justify-center p-4"
            >
              <button 
                onClick={() => setSelectedImage(null)}
                className="absolute top-10 right-10 z-[110] p-2 bg-white/10 rounded-full"
              >
                <X size={24} />
              </button>
              <motion.img 
                layoutId={selectedImage.id}
                src={selectedImage.url} 
                className="max-w-full max-h-full object-contain"
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  return (
    <div className="p-6 h-full">
      <header className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Photo Albums</h1>
        <button 
          onClick={() => setShowAddFolder(true)}
          className="p-2 bg-rose-600 rounded-full"
        >
          <Plus size={20} />
        </button>
      </header>

      <div className="grid grid-cols-2 gap-4">
        {folders.map((folder) => (
          <motion.button
            key={folder.id}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveFolderId(folder.id)}
            className="flex flex-col items-center bg-slate-900/60 p-6 rounded-3xl border border-white/5"
          >
            <Folder size={48} className="text-rose-500 mb-3" fill="rgba(244, 63, 94, 0.2)" />
            <span className="font-bold truncate w-full text-center">{folder.name}</span>
            <span className="text-[10px] text-slate-500 uppercase tracking-widest mt-1">{folder.files.length} items</span>
          </motion.button>
        ))}
        {folders.length === 0 && (
          <div className="col-span-2 py-20 text-center text-slate-500">
            <p>Create your first folder<br/>to organize memories.</p>
          </div>
        )}
      </div>

      <AnimatePresence>
        {showAddFolder && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-6">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-sm bg-slate-900 border border-rose-500/20 rounded-3xl p-8"
            >
              <h3 className="text-xl font-bold mb-6">New Album Name</h3>
              <input 
                type="text" 
                autoFocus
                className="w-full bg-slate-800 border border-slate-700 rounded-2xl px-4 py-3 mb-6 focus:outline-none focus:border-rose-500"
                placeholder="e.g., Beach Trip 2024"
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
              />
              <div className="flex gap-4">
                <button 
                  onClick={() => setShowAddFolder(false)}
                  className="flex-1 py-3 bg-slate-800 rounded-2xl font-bold"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleAddFolder}
                  className="flex-1 py-3 bg-rose-600 rounded-2xl font-bold"
                >
                  Create
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
