
import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Image as ImageIcon } from 'lucide-react';
import { APP_GREETING } from '../constants';
import { AppState } from '../types';

export const Home: React.FC<{ state: AppState; updateState: (u: Partial<AppState>) => void }> = ({ state, updateState }) => {
  const handleBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateState({ backgroundUrl: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="p-6 h-full flex flex-col">
      <header className="mb-8 pt-8 text-center">
        <motion.h1 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-3xl font-romantic text-rose-500 mb-2 neon-glow"
        >
          {APP_GREETING}
        </motion.h1>
        <p className="text-slate-300 italic font-serif opacity-80">Welcome to our safe place</p>
      </header>

      <div className="grid grid-cols-2 gap-4 flex-1 items-start content-start">
        <motion.div 
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="col-span-2 relative h-48 rounded-3xl overflow-hidden group border border-rose-500/20"
        >
          <img 
            src={state.backgroundUrl || ''} 
            className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" 
            alt="Current background"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-6">
            <h3 className="text-xl font-bold mb-1">Our Theme</h3>
            <p className="text-xs text-slate-300">Tap to change background</p>
            <input 
              type="file" 
              accept="image/*" 
              className="absolute inset-0 opacity-0 cursor-pointer" 
              onChange={handleBgUpload}
            />
          </div>
          <div className="absolute top-4 right-4 p-2 bg-black/50 backdrop-blur-md rounded-full">
            <ImageIcon size={18} className="text-rose-500" />
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="bg-slate-900/80 backdrop-blur-xl p-6 rounded-3xl border border-white/5 flex flex-col items-center justify-center text-center shadow-xl"
        >
          <div className="w-12 h-12 bg-rose-500/20 rounded-2xl flex items-center justify-center mb-4">
            <Heart size={24} className="text-rose-500" fill="currentColor" />
          </div>
          <h4 className="text-2xl font-bold text-rose-500">{state.photoFolders.reduce((acc, f) => acc + f.files.length, 0)}</h4>
          <p className="text-xs text-slate-400 uppercase font-bold tracking-widest mt-1">Photos Saved</p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="bg-slate-900/80 backdrop-blur-xl p-6 rounded-3xl border border-white/5 flex flex-col items-center justify-center text-center shadow-xl"
        >
          <div className="w-12 h-12 bg-rose-500/20 rounded-2xl flex items-center justify-center mb-4">
            <Heart size={24} className="text-rose-500" fill="currentColor" />
          </div>
          <h4 className="text-2xl font-bold text-rose-500">{state.letters.length}</h4>
          <p className="text-xs text-slate-400 uppercase font-bold tracking-widest mt-1">Love Letters</p>
        </motion.div>
      </div>

      <div className="mt-8">
        <div className="bg-rose-600/10 border border-rose-500/20 p-6 rounded-3xl text-center italic font-serif">
          "The best thing to hold onto in life is each other."
        </div>
      </div>
    </div>
  );
};
