
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, ChevronLeft, Save, Trash2, Calendar } from 'lucide-react';
import { Letter } from '../types';

export const Letters: React.FC<{ letters: Letter[]; onUpdate: (l: Letter[]) => void }> = ({ letters, onUpdate }) => {
  const [editingLetter, setEditingLetter] = useState<Letter | null>(null);
  const [viewingLetter, setViewingLetter] = useState<Letter | null>(null);

  const handleSave = () => {
    if (editingLetter) {
      if (editingLetter.id === 'new') {
        const newLetter = { ...editingLetter, id: Date.now().toString(), timestamp: Date.now() };
        onUpdate([newLetter, ...letters]);
      } else {
        onUpdate(letters.map(l => l.id === editingLetter.id ? editingLetter : l));
      }
      setEditingLetter(null);
    }
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Burn this letter? This cannot be undone.')) {
      onUpdate(letters.filter(l => l.id !== id));
      setViewingLetter(null);
    }
  };

  if (editingLetter) {
    return (
      <div className="p-6 h-full flex flex-col bg-slate-950">
        <header className="flex items-center justify-between mb-8">
          <button onClick={() => setEditingLetter(null)} className="text-slate-400 font-bold">Cancel</button>
          <h2 className="text-xl font-romantic text-rose-500">Writing...</h2>
          <button onClick={handleSave} className="p-2 bg-rose-600 rounded-full"><Save size={20}/></button>
        </header>
        <input 
          type="text" 
          placeholder="Subject of my heart..." 
          className="bg-transparent border-none text-2xl font-bold mb-4 focus:outline-none placeholder:opacity-30"
          value={editingLetter.title}
          onChange={(e) => setEditingLetter({ ...editingLetter, title: e.target.value })}
        />
        <p className="text-xs text-rose-500/50 mb-6 uppercase tracking-[0.2em]">{editingLetter.date || new Date().toLocaleDateString()}</p>
        <textarea 
          placeholder="My dearest, I've been thinking about..."
          className="flex-1 bg-transparent border-none resize-none focus:outline-none text-lg leading-relaxed font-serif text-slate-200"
          value={editingLetter.content}
          onChange={(e) => setEditingLetter({ ...editingLetter, content: e.target.value })}
        />
      </div>
    );
  }

  if (viewingLetter) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 1.05 }}
        animate={{ opacity: 1, scale: 1 }}
        className="p-8 h-full overflow-y-auto bg-amber-50 text-slate-900 flex flex-col items-center"
      >
        <div className="max-w-xl w-full">
          <header className="flex justify-between items-center mb-12 border-b border-amber-200 pb-4">
            <button onClick={() => setViewingLetter(null)} className="p-2 rounded-full hover:bg-amber-100"><ChevronLeft size={24} /></button>
            <div className="flex gap-4">
              <button onClick={() => { setEditingLetter(viewingLetter); setViewingLetter(null); }} className="text-blue-600 font-bold text-sm">Edit</button>
              <button onClick={() => handleDelete(viewingLetter.id)} className="text-rose-600 font-bold text-sm">Delete</button>
            </div>
          </header>
          <h1 className="text-4xl font-romantic mb-2">{viewingLetter.title}</h1>
          <p className="text-slate-400 font-bold text-xs uppercase tracking-widest mb-10">{viewingLetter.date}</p>
          <div className="whitespace-pre-wrap font-serif text-xl leading-relaxed text-slate-800">
            {viewingLetter.content}
          </div>
          <div className="mt-12 pt-8 border-t border-amber-200 font-romantic text-2xl">
            Forever yours, <br/>
            Kash ❤
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="p-6 h-full">
      <header className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Love Letters</h1>
        <button 
          onClick={() => setEditingLetter({ id: 'new', title: '', content: '', date: new Date().toLocaleDateString(), timestamp: Date.now() })}
          className="p-2 bg-rose-600 rounded-full"
        >
          <Plus size={20} />
        </button>
      </header>

      <div className="space-y-4">
        {letters.map((letter) => (
          <motion.button
            key={letter.id}
            whileTap={{ scale: 0.98 }}
            onClick={() => setViewingLetter(letter)}
            className="w-full bg-slate-900/60 p-6 rounded-3xl border border-white/5 flex flex-col text-left"
          >
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-xl font-bold text-rose-500 font-romantic">{letter.title || 'Untitled Heartbeat'}</h3>
              <Calendar size={14} className="opacity-30" />
            </div>
            <p className="text-slate-400 text-sm line-clamp-2 italic font-serif mb-2 opacity-60">
              {letter.content}
            </p>
            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">{letter.date}</span>
          </motion.button>
        ))}
        {letters.length === 0 && (
          <div className="py-20 text-center text-slate-500">
            <p>Your mailbox is empty.<br/>Pour your heart out.</p>
          </div>
        )}
      </div>
    </div>
  );
};
