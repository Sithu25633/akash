
import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SplashScreen } from './components/SplashScreen';
import { SecurityOverlay } from './components/SecurityOverlay';
import { AuthScreen } from './components/AuthScreen';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Photos } from './pages/Photos';
import { Videos } from './pages/Videos';
import { Letters } from './pages/Letters';
import { Counter } from './pages/Counter';
import { GeminiAI } from './pages/GeminiAI';
import { AppState } from './types';

const INITIAL_STATE: AppState = {
  unlocked: false,
  isLoggedIn: false,
  currentUser: null,
  backgroundUrl: 'https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&q=80',
  startDate: new Date().toISOString(),
  counterTitle: 'Our Love Story',
  photoFolders: [],
  videoFolders: [],
  letters: [],
  aiMessages: []
};

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [state, setState] = useState<AppState>(() => {
    const saved = localStorage.getItem('manika_app_state');
    return saved ? JSON.parse(saved) : INITIAL_STATE;
  });
  const [activeTab, setActiveTab] = useState('home');

  // Persistence
  useEffect(() => {
    const { unlocked, ...rest } = state;
    // We don't persist 'unlocked' state across browser closes for security, 
    // but the request said "persist after refresh", so we use sessionStorage for 'unlocked'.
    localStorage.setItem('manika_app_state', JSON.stringify(rest));
  }, [state]);

  useEffect(() => {
    const isUnlocked = sessionStorage.getItem('manika_unlocked') === 'true';
    if (isUnlocked) setState(prev => ({ ...prev, unlocked: true }));
    
    // Security: Right click disable
    const handleContextMenu = (e: MouseEvent) => e.preventDefault();
    document.addEventListener('contextmenu', handleContextMenu);
    
    // Security: DevTools warning
    const handleKeydown = (e: KeyboardEvent) => {
      if (e.key === 'F12' || (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'J' || e.key === 'C'))) {
        alert("Security Alert: Developer Tools are restricted for privacy.");
      }
    };
    document.addEventListener('keydown', handleKeydown);

    return () => {
      document.removeEventListener('contextmenu', handleContextMenu);
      document.removeEventListener('keydown', handleKeydown);
    };
  }, []);

  const handleUnlock = useCallback((success: boolean) => {
    if (success) {
      sessionStorage.setItem('manika_unlocked', 'true');
      setState(prev => ({ ...prev, unlocked: true }));
    }
  }, []);

  const handleLogin = useCallback((username: string) => {
    setState(prev => ({ ...prev, isLoggedIn: true, currentUser: username }));
  }, []);

  const updateState = useCallback((updates: Partial<AppState>) => {
    setState(prev => ({ ...prev, ...updates }));
  }, []);

  if (showSplash) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  if (!state.unlocked) {
    return <SecurityOverlay onUnlock={handleUnlock} />;
  }

  if (!state.isLoggedIn) {
    return <AuthScreen onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'home': return <Home state={state} updateState={updateState} />;
      case 'photos': return <Photos folders={state.photoFolders} onUpdate={(f) => updateState({ photoFolders: f })} />;
      case 'videos': return <Videos folders={state.videoFolders} onUpdate={(f) => updateState({ videoFolders: f })} />;
      case 'letters': return <Letters letters={state.letters} onUpdate={(l) => updateState({ letters: l })} />;
      case 'counter': return <Counter startDate={state.startDate} title={state.counterTitle} onUpdate={(d, t) => updateState({ startDate: d, counterTitle: t })} />;
      case 'gemini': return <GeminiAI messages={state.aiMessages} onUpdate={(m) => updateState({ aiMessages: m })} />;
      default: return <Home state={state} updateState={updateState} />;
    }
  };

  return (
    <Layout activeTab={activeTab} setActiveTab={setActiveTab} backgroundUrl={state.backgroundUrl}>
      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="h-full overflow-y-auto pb-24"
        >
          {renderContent()}
        </motion.div>
      </AnimatePresence>
    </Layout>
  );
};

export default App;
