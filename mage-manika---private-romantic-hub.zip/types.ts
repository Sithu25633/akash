
export type MediaFile = {
  id: string;
  url: string;
  name: string;
  type: 'image' | 'video';
  timestamp: number;
};

export type Folder = {
  id: string;
  name: string;
  files: MediaFile[];
};

export type Letter = {
  id: string;
  title: string;
  content: string;
  date: string;
  timestamp: number;
};

export type AppState = {
  unlocked: boolean;
  isLoggedIn: boolean;
  currentUser: string | null;
  backgroundUrl: string | null;
  startDate: string;
  counterTitle: string;
  photoFolders: Folder[];
  videoFolders: Folder[];
  letters: Letter[];
  aiMessages: { text: string; date: string }[];
};
