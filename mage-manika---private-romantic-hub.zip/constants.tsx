
import React from 'react';
import { Heart, Camera, Video, PenTool, Calendar, Sparkles, Settings } from 'lucide-react';

export const PIN_CODE = "1234"; // Default security pin
export const APP_GREETING = "Subodasanak mage manika ❤";

export const NAVIGATION_ITEMS = [
  { id: 'home', label: 'Home', icon: <Heart size={24} /> },
  { id: 'photos', label: 'Photos', icon: <Camera size={24} /> },
  { id: 'videos', label: 'Videos', icon: <Video size={24} /> },
  { id: 'letters', label: 'Letters', icon: <PenTool size={24} /> },
  { id: 'counter', label: 'Counter', icon: <Calendar size={24} /> },
  { id: 'gemini', label: 'AI Love', icon: <Sparkles size={24} /> },
];

export const MOCK_QUOTES = [
  "You're the peace I've been looking for.",
  "Home is wherever I am with you.",
  "Every love story is beautiful, but ours is my favorite.",
  "In you, I've found my best friend and my soulmate.",
  "My heart is and always will be yours."
];
